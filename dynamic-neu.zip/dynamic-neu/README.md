# Dynamic NEU – Quanh NEU có gì?

Trang web tĩnh hỗ trợ sinh viên Đại học Kinh tế Quốc dân (207 Giải Phóng, Hà Nội):

- Sổ chi tiêu, dự báo cuối tháng và điểm tiết kiệm (lưu trong `localStorage`, không gửi dữ liệu đi đâu)
- So sánh vé xe buýt lượt và vé tháng
- Gợi ý món ăn theo ngân sách và nhu cầu
- Danh sách quán ăn, cà phê học bài, giải trí, cây xăng quanh NEU, có tìm kiếm và lọc theo khoảng cách
- Các tuyến xe buýt đi qua khu vực trường

Không cần cài đặt hay build. Chỉ có HTML, CSS và JavaScript thuần.

## Chạy thử trên máy

Mở `index.html` bằng trình duyệt, hoặc chạy server nhỏ:

```bash
python3 -m http.server 8000
```

Rồi vào http://localhost:8000.

## Đưa lên GitHub và bật GitHub Pages

```bash
cd dynamic-neu
git init -b main
git add .
git commit -m "Dynamic NEU: bản đầu tiên"
git remote add origin https://github.com/<ten-ban>/dynamic-neu.git
git push -u origin main
```

Sau đó vào **Settings → Pages → Build and deployment**, chọn **Deploy from a branch**, nhánh `main`, thư mục `/ (root)`. Vài phút sau trang chạy tại `https://<ten-ban>.github.io/dynamic-neu/`.

## Cấu trúc

```
index.html        Nội dung trang
css/style.css     Giao diện (có chế độ tối theo hệ thống)
js/data.js        Danh sách địa điểm (sửa ở đây để cập nhật quán)
js/places.js      Lọc, tìm kiếm và hiển thị địa điểm
js/app.js         Sổ chi tiêu, vé xe, gợi ý món, trợ lý
```

## Thêm một địa điểm

Thêm một object vào mảng `items` trong `js/data.js`:

```js
{"t": "cafe", "n": "Tên quán", "a": "Địa chỉ", "m": 300, "h": "7:00–22:00",
 "p": "Giá tham khảo", "x": "Mô tả ngắn", "l": "https://www.google.com/maps/search/?api=1&query=..."}
```

`t` là loại (`food`, `cafe`, `fun`, `xang`), `m` là khoảng cách đường chim bay từ NEU tính bằng mét.

## Lưu ý dữ liệu

Giá và giờ mở cửa lấy từ Google Maps và bài viết ẩm thực, có thể đã đổi. Khoảng cách là đường chim bay.

## Giấy phép

MIT, xem file `LICENSE`.
