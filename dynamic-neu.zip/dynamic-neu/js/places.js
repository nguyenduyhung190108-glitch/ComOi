var kind="all",max=6000,q="",L=document.getElementById("list");
var lab={food:"Đồ ăn",cafe:"Cà phê",fun:"Giải trí",xang:"Cây xăng"};
function norm(s){return s.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g,"").replace(/đ/g,"d")}
function fmt(m){return m<1000?m+" m":(m/1000).toFixed(1).replace(".",",")+" km"}
function render(){
 L.innerHTML="";var n=0,shown=false;
 items.forEach(function(i){
  if(kind!=="all"&&i.t!==kind)return;
  if(q&&norm([i.n,i.a,i.x].join(" ")).indexOf(q)<0)return;
  if(i.m!==null&&i.m>max)return;
  if(i.m===null&&max<6000)return;
  if(i.m===null&&!shown){var s=document.createElement("div");s.className="sep";s.textContent="Chưa có khoảng cách (cùng khu Trần Đại Nghĩa, ngõ Tự Do)";L.appendChild(s);shown=true}
  var c=document.createElement("div");c.className="card";
  c.innerHTML='<div class="dist"></div><div><h3></h3><div class="a"></div><div class="meta"></div></div><a class="map" target="_blank" rel="noopener">Xem bản đồ</a>';
  var d=c.querySelector(".dist");
  if(i.m===null){d.textContent="?";d.innerHTML+="<small>chưa rõ</small>"}else{d.textContent=fmt(i.m);d.innerHTML+="<small>từ NEU</small>"}
  c.querySelector("h3").textContent=i.n;
  c.querySelector(".a").textContent=i.a;
  var m=c.querySelector(".meta");
  var t=document.createElement("span");t.className="tag";t.textContent=lab[i.t];m.appendChild(t);
  m.appendChild(document.createTextNode(i.x+" · "+i.h+" · "+i.p));
  c.querySelector(".map").href=i.l;
  L.appendChild(c);n++});
 document.getElementById("cnt").textContent=n+" địa điểm";
 if(!n)L.innerHTML='<p class="lead">Không tìm thấy địa điểm phù hợp. Hãy tăng khoảng cách hoặc đổi từ khóa.</p>';
}
document.querySelectorAll("#tabs .tab").forEach(function(b){b.onclick=function(){
 document.querySelectorAll("#tabs .tab").forEach(function(o){o.setAttribute("aria-pressed",o===b)});kind=b.dataset.k;render()}});
var r=document.getElementById("rng");
r.oninput=function(){max=+r.value;document.getElementById("rv").textContent=max.toLocaleString("vi-VN")+" m";render()};
document.getElementById("q").oninput=function(){q=norm(this.value.trim());render()};
render();

