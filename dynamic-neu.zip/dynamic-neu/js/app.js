(function(){
var vnd=function(n){return Math.round(n).toLocaleString("vi-VN")+"đ"};
var today=function(){var d=new Date();return d.getFullYear()+"-"+String(d.getMonth()+1).padStart(2,"0")+"-"+String(d.getDate()).padStart(2,"0")};
var $=function(i){return document.getElementById(i)};
var num=function(e){return +String(e.value).replace(/\D/g,"")||0};
var money=function(e){var n=num(e);e.value=n?n.toLocaleString("vi-VN"):""};
/* Gợi ý món */
var dishes=[{n:"Cơm tấm sườn trứng",p:35000,t:["nhanh"],w:"Quán cơm bình dân"},{n:"Bún riêu cua",p:30000,t:["nuoc"],w:"Quán bún"},{n:"Bánh mì trứng ốp la",p:15000,t:["nhanh"],w:"Xe bánh mì đầu ngõ"},{n:"Phở gà",p:35000,t:["nuoc","lanh"],w:"Quán phở"},{n:"Cơm rau luộc, đậu sốt cà",p:25000,t:["lanh","nhanh"],w:"Cơm chay"},{n:"Mì cay hải sản",p:45000,t:["cay","nuoc"],w:"Quán mì cay"},{n:"Bún chả",p:40000,t:["nhanh"],w:"Quán bún chả"},{n:"Salad gà áp chảo",p:55000,t:["lanh","nhanh"],w:"Tiệm ăn healthy"},{n:"Bánh tráng trộn",p:20000,t:["cay","nhanh"],w:"Xe ăn vặt"},{n:"Cháo trứng bắc thảo",p:25000,t:["nuoc","lanh"],w:"Quán cháo"},{n:"Lẩu thái mini",p:70000,t:["cay","nuoc"],w:"Quán lẩu sinh viên"},{n:"Xôi mặn thập cẩm",p:20000,t:["nhanh"],w:"Xôi sáng"}];
var sel={},bud=35000;
$("m-b").oninput=function(){bud=+this.value;$("m-bv").textContent=vnd(bud)};
document.querySelectorAll("#m-chips .chip").forEach(function(c){c.onclick=function(){var k=c.dataset.t;sel[k]=!sel[k];c.setAttribute("aria-pressed",!!sel[k])}});
function suggest(){var ks=Object.keys(sel).filter(function(k){return sel[k]});
 var l=dishes.filter(function(d){return d.p<=bud&&ks.every(function(k){return d.t.indexOf(k)>-1})}).sort(function(){return Math.random()-.5});
 var r=$("m-res");r.innerHTML="";
 if(!l.length){r.innerHTML='<p class="sub" style="margin-top:10px">Chưa có món hợp. Thử tăng ngân sách hoặc bỏ bớt một nhu cầu.</p>';return}
 l.slice(0,3).forEach(function(d){var e=document.createElement("div");e.className="dish";e.innerHTML="<div><strong></strong><small></small></div><span class='price'></span>";
  e.querySelector("strong").textContent=d.n;e.querySelector("small").textContent=d.w;e.querySelector(".price").textContent=vnd(d.p);r.appendChild(e)})}
$("m-go").onclick=suggest;suggest();
/* Sổ chi tiêu */
var cats=[["an","Ăn uống",35,"#e8452c"],["tro","Nhà trọ, điện nước",30,"#0b2a6f"],["dilai","Đi lại",8,"#2e8bff"],["hoc","Học tập",10,"#18a37b"],["giaitri","Giải trí",8,"#8b5cf6"],["muasam","Mua sắm",5,"#ffc21a"],["khac","Khác",4,"#7a8499"]];
var tipmap={an:"Ăn uống chiếm tỷ lệ cao. Thử nấu chung vài bữa mỗi tuần hoặc chọn quán dưới 35.000đ.",tro:"Tiền trọ chiếm phần lớn. Cân nhắc ở ghép hoặc hỏi lại giá điện nước.",dilai:"Đi lại tốn khá nhiều. Hãy so sánh vé tháng xe buýt ở mục Xe buýt.",hoc:"Chi cho học tập khá cao. Kiểm tra xem có thể mượn giáo trình ở thư viện không.",giaitri:"Giải trí vượt mức gợi ý. Đặt hạn mức cho mỗi cuối tuần.",muasam:"Mua sắm vượt mức gợi ý. Đợi 24 giờ trước khi mua món chưa thật cần.",khac:"Nhóm Khác khá lớn. Hãy ghi chú rõ để biết tiền đi đâu."};
var S={inc:3000000,goal:20,ex:[]};
var cs=$("x-cat");cats.forEach(function(c){var o=document.createElement("option");o.value=c[0];o.textContent=c[1];cs.appendChild(o)});
try{var raw=localStorage.getItem("neu_expense");if(raw){var p=JSON.parse(raw);if(p&&p.ex)S=p}}catch(e){}
function save(){try{localStorage.setItem("neu_expense",JSON.stringify(S))}catch(e){}}
$("x-inc").value=S.inc.toLocaleString("vi-VN");$("x-goal").value=S.goal;$("x-gv").textContent=S.goal+"%";
$("x-inc").oninput=function(){money(this);S.inc=num(this);save();calc()};
$("x-goal").oninput=function(){S.goal=+this.value;$("x-gv").textContent=S.goal+"%";save();calc()};
function msg(t){$("x-msg").textContent=t}
function add(a,c,n){S.ex.push({id:Date.now()+Math.random(),a:a,c:c,n:n||"",d:today()});save();calc()}
$("x-add").onclick=function(){var a=num($("x-amt"));if(!(a>0)){msg("Nhập số tiền lớn hơn 0 để thêm khoản chi.");return}
 add(a,cs.value,$("x-note").value.trim());$("x-amt").value="";$("x-note").value="";msg("Đã thêm khoản chi.")};
$("x-amt").oninput=function(){money(this)};
$("x-amt").onkeydown=function(e){if(e.key==="Enter")$("x-add").onclick()};
$("x-demo").onclick=function(){S.ex=[];[[1000000,"tro","Tiền trọ"],[220000,"an","Ăn uống tuần đầu"],[40000,"dilai","Xe buýt"],[60000,"hoc","Giáo trình, in ấn"],[50000,"giaitri","Xem phim, cà phê"],[60000,"muasam","Đồ dùng cá nhân"],[20000,"khac","Linh tinh"]].forEach(function(x){S.ex.push({id:Date.now()+Math.random(),a:x[0],c:x[1],n:x[2],d:today()})});save();calc();msg("Đã nạp dữ liệu mẫu.")};
$("x-clear").onclick=function(){S.ex=[];save();calc();msg("Đã xóa tất cả khoản chi.")};
var last=null;
function calc(){
 var now=new Date(),ym=today().slice(0,7),dim=new Date(now.getFullYear(),now.getMonth()+1,0).getDate(),day=now.getDate();
 var ex=S.ex.filter(function(e){return e.d.slice(0,7)===ym});
 var tot={};cats.forEach(function(c){tot[c[0]]=0});ex.forEach(function(e){tot[e.c]=(tot[e.c]||0)+e.a});
 var spent=0;cats.forEach(function(c){spent+=tot[c[0]]});
 var fixed=tot.tro,varSp=spent-fixed,proj=fixed+varSp+varSp/Math.max(day,7)*(dim-day);
 var limit=S.inc*(1-S.goal/100),left=limit-spent,perDay=Math.max(0,left)/(dim-day+1);
 var ratio=limit>0?proj/limit:0,score=ratio<=1?Math.max(80,Math.round(100-Math.max(0,ratio-.8)*100)):Math.max(0,Math.round(80-(ratio-1)*160));
 var v=$("x-verdict");
 if(!spent){v.className="verdict v-mid";v.textContent="Chưa có khoản chi nào. Thêm khoản chi hoặc nạp dữ liệu mẫu để xem phân tích."}
 else if(proj<=limit){v.className="verdict v-good";v.textContent="Tiết kiệm tốt: với nhịp chi này, cuối tháng bạn dự kiến để dành khoảng "+vnd(S.inc-proj)+". Điểm "+score+"/100."}
 else if(proj<=S.inc){v.className="verdict v-mid";v.textContent="Cân bằng nhưng chưa đạt mục tiêu: dự kiến chi "+vnd(proj)+", vượt hạn mức tiết kiệm "+vnd(proj-limit)+". Điểm "+score+"/100."}
 else{v.className="verdict v-bad";v.textContent="Chi quá tay: dự kiến chi "+vnd(proj)+", vượt tiền sinh hoạt "+vnd(proj-S.inc)+". Điểm "+score+"/100."}
 $("x-kpi").innerHTML="";
 [["Đã chi",vnd(spent)],["Hạn mức chi",vnd(limit)],["Còn lại",vnd(left)],["Dự báo cuối tháng",vnd(proj)],["Nên chi mỗi ngày",vnd(perDay)]].forEach(function(k){var d=document.createElement("div");d.className="kpi";d.innerHTML="<small></small><b></b>";d.querySelector("small").textContent=k[0];d.querySelector("b").textContent=k[1];$("x-kpi").appendChild(d)});
 var acc=0,st=[];cats.forEach(function(c){var s=spent?tot[c[0]]/spent*100:0;if(s>0){st.push(c[3]+" "+acc+"% "+(acc+s)+"%");acc+=s}});
 $("x-donut").style.background=st.length?"conic-gradient("+st.join(",")+")":"var(--soft)";
 var B=$("x-bars");B.innerHTML="";var tips=[];
 cats.forEach(function(c){var s=spent?tot[c[0]]/spent*100:0,r=document.createElement("div");r.className="brow";
  r.innerHTML='<div class="t"><span></span><span></span></div><div class="track"><i></i><u></u></div>';
  r.querySelector(".t span").textContent=c[1];r.querySelectorAll(".t span")[1].textContent=Math.round(s)+"% · "+vnd(tot[c[0]]);
  var i=r.querySelector("i");i.style.width=Math.min(100,s)+"%";i.style.background=c[3];r.querySelector("u").style.left=c[2]+"%";B.appendChild(r);
  if(spent&&s>=c[2]+8)tips.push(tipmap[c[0]])});
 if(spent&&left<0)tips.unshift("Bạn đã chi vượt hạn mức tháng này "+vnd(-left)+". Tạm dừng các khoản chưa cần thiết.");
 if(spent&&!tips.length)tips.push("Cơ cấu chi tiêu khá hợp lý so với mức gợi ý. Giữ nhịp chi hiện tại để đạt mục tiêu tiết kiệm.");
 if(!spent)tips.push("Ghi lại mọi khoản chi trong vài ngày để phân tích chính xác hơn.");
 if(spent&&day<7)tips.push("Mới đầu tháng nên dự báo có thể chưa chính xác, hãy theo dõi thêm.");
 $("x-tips").innerHTML="";tips.forEach(function(t){var li=document.createElement("li");li.textContent=t;$("x-tips").appendChild(li)});
 var L2=$("x-list");L2.innerHTML="";
 if(!ex.length)L2.innerHTML='<p class="sub">Chưa có khoản chi nào.</p>';
 ex.slice(-8).reverse().forEach(function(e){var cn=cats.filter(function(c){return c[0]===e.c})[0][1],r=document.createElement("div");r.className="exp";
  r.innerHTML='<span></span><span><b></b> <button aria-label="Xóa khoản chi">×</button></span>';
  r.querySelector("span").textContent=cn+(e.n?" · "+e.n:"");r.querySelector("b").textContent=vnd(e.a);
  r.querySelector("button").onclick=function(){S.ex=S.ex.filter(function(x){return x.id!==e.id});save();calc()};L2.appendChild(r)});
 last={spent:spent,proj:proj,limit:limit,left:left,tot:tot,score:score,perDay:perDay};
}
calc();
/* Vé xe buýt */
function fare(){money($("f-tp"));money($("f-mp"));var tp=num($("f-tp")),mp=num($("f-mp")),t=+$("f-td").value,d=+$("f-dm").value;$("f-tdv").textContent=t;$("f-dmv").textContent=d;
 var s=tp*t*d;$("f-res").textContent=s>mp?"Nên mua vé tháng, tiết kiệm "+vnd(s-mp):"Mua vé lượt, rẻ hơn "+vnd(mp-s)}
["f-tp","f-mp","f-td","f-dm"].forEach(function(i){$(i).oninput=fare});fare();
/* Chat */
function reply(t){t=t.toLowerCase();
 if(/phân tích|chi tiêu|tiết kiệm|tiền/.test(t)){if(!last||!last.spent)return "Bạn chưa ghi khoản chi nào. Vào mục Sổ chi tiêu để thêm khoản chi hoặc nạp dữ liệu mẫu.";
  var top=cats.slice().sort(function(a,b){return last.tot[b[0]]-last.tot[a[0]]})[0];
  return "Bạn đã chi "+vnd(last.spent)+", dự báo cuối tháng "+vnd(last.proj)+" (hạn mức "+vnd(last.limit)+"). Nhóm chi nhiều nhất là "+top[1]+". Điểm tiết kiệm "+last.score+"/100, nên chi khoảng "+vnd(last.perDay)+" mỗi ngày."}
 if(/xe buýt|bus|đi lại|tuyến/.test(t))return "Các tuyến đi qua NEU gồm 18, 47B, 21A, 21B, 25, 32, 23 và vài tuyến khác. Xem mục Xe buýt để so sánh vé lượt với vé tháng.";
 if(/học bài|cà phê|cafe/.test(t))return "Mục Quanh NEU có Canopy StudySpace (mở 24 giờ), Bee Coffee, coffee later? và các quán học bài khác, xếp theo khoảng cách.";
 if(/ăn|đói|cơm|bún|phở|rẻ/.test(t))return "Kéo thanh ngân sách ở mục Hôm nay ăn gì? để nhận gợi ý, hoặc xem quán thật quanh NEU kèm địa chỉ.";
 return "Mình chưa hiểu rõ. Bạn thử hỏi về chi tiêu, ăn uống, xe buýt hoặc quán học bài nhé."}
function ask(t){if(!t.trim())return;var c=$("c-chat"),m=document.createElement("div");m.className="msg me";m.textContent=t;c.appendChild(m);
 var r=document.createElement("div");r.className="msg ai";r.textContent=reply(t);c.appendChild(r);c.scrollTop=c.scrollHeight}
$("c-send").onclick=function(){ask($("c-q").value);$("c-q").value=""};
$("c-q").onkeydown=function(e){if(e.key==="Enter"){ask($("c-q").value);$("c-q").value=""}};
document.querySelectorAll("#c-quick .chip").forEach(function(c){c.onclick=function(){ask(c.textContent)}});
})();
